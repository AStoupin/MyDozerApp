import {Modal, Table} from "antd";

import React, { useEffect, useState} from "react";
import {Key, RowSelectMethod} from "antd/lib/table/interface";

const symbols = [
    {key: "A", id: "A", name: "Symbol A"},
    {key: "B", id: "B", name: "Symbol B"},
    {key: "C", id: "C", name: "Symbol C"},
]

const columns = [
    {

        title: 'id',
        dataIndex: 'id',
        key: 'id',
    },
    {
        title: 'name',
        dataIndex: 'name',
        key: 'name',
    },

];

export const useSymbolModal= ({closeCallback}) => {
    const [showModal, setShowModal] = useState(false);
    const [value, setValue] = useState();

    const closeModal = (symbolValue) => {
        setShowModal(false)
        closeCallback(symbolValue)
    }

    const openModal = (symbolValue) => {
        console.log(`openModal ${symbolValue}`);
        setValue(symbolValue)
        setShowModal(true)

    }



    return {
        showModal,
        value,
        setValue,
        closeModal,
        openModal
    }
}

export const SymbolModal = ({symbolModal}) => {



    const handleOk = () => {
        console.log("handleOk");
        symbolModal.closeModal(symbolModal.value)
    };

    const handleCancel = () => {
        console.log("handleCancel");
        symbolModal.closeModal(null)
    };

    const rowSelection = {
        type: 'radio',
        selectedRowKeys: symbolModal.value,
        onChange: (newSelectedRowKeys: React.Key[], selectedRows: DataType[]) =>  onSelectChange(newSelectedRowKeys, selectedRows)
    };

    const onSelectChange = (newSelectedRowKeys: React.Key[], selectedRows: DataType[]) => {
        console.log('selectedRowKeys changed: ', selectedRows);
        symbolModal.setValue(newSelectedRowKeys[0]);

    };


    return (
      <Modal  open={symbolModal.showModal} onOk={handleOk} onCancel={handleCancel}>

          <Table dataSource={symbols} columns={columns} rowSelection={rowSelection}  ></Table>
          <pre>
                 {JSON.stringify(symbolModal, undefined, 4)}
          </pre>
      </Modal>
    );
}