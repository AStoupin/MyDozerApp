
import React, {Component, useContext, useEffect, useRef, useState} from 'react';

import {Button, Card, DatePicker, Input, Space, Table, version} from "antd";

import 'antd/dist/antd.dark.less';


import SplitAccountModal, {useSplitAccountModal} from "./SplitAccountModal";

const initialPackageTable =  [
    {
        key: 1,
        name: 'Mike',
        age: 32,
        address: '10 Downing Street',
        accounts: [
            {
                key: 1,
                account: "account1",
                symbols: [
                    {symbol: "A", amount: 100},
                    {symbol: "B", amount: 160}
                ]
            },
            {
                key: 2,
                account: "account2",
                symbols: [
                    {symbol: "A", amount: 101},
                    {symbol: "B", amount: 161}
                ]
            }


        ]
    },
    {
        key: 2,
        name: 'John',
        age: 42,
        address: '10 Downing Street',
        accounts: [
            {
                key: 1,
                account: "account3",
                symbols: [
                    {symbol: "A", amount: 100},
                    {symbol: "C", amount: 160}
                ]
            },
            {
                key: 2,
                account: "account4",
                symbols: [
                    {symbol: "A", amount: 101},
                    {symbol: "C", amount: 161}
                ]
            }
        ]
    },
];

const useClientList = () => {
    const [dataSource, setDataSource] = useState(initialPackageTable);

    const updateRow = (row) => {

        const map = new Map(dataSource.map(obj => [obj.key, obj]))

        map.set(row.key, row);

        setDataSource(Array.from(map.values()));

    }


    return {
        dataSource,
        updateRow
    }
}

const ClientList = ()=>{
    const clientList = useClientList();

    const SplitAccountButton = ({row}) => {

        const splitAccountModal = useSplitAccountModal({closeCallback: (newValue)=>onCloseModal(newValue)});

        const  onClick  = () => {
            console.log("click")

            splitAccountModal.openModal(row.accounts);
        }

        const onCloseModal = (newValue) => {
            if(newValue==null) {
                return;
            }
            const newRow = {...row, accounts: newValue};
            clientList.updateRow(newRow);

            console.log("SplitAccountModal closed with value");
            console.log(newValue);
        }

      return (
          <div>
            <Button onClick={onClick}>{row.key}</Button>
            <SplitAccountModal splitAccountModal={splitAccountModal}></SplitAccountModal>
          </div>
      );
    }

    const RenderSplitAccountButton = (_, row) => {

        return (  <SplitAccountButton row={row}/>
            );
    }

    const columns = [
        {

            title: 'key',
            dataIndex: 'key',
            key: 'key',
        },
        {

            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {

            title: 'Age',
            dataIndex: 'age',
            key: 'age',
        },
        {

            title: 'Address',
            dataIndex: 'address',
            key: 'address',
        },

        {
            render: RenderSplitAccountButton,
            title: 'Change',
            dataIndex: 'key',
            key: 'key',
        },
    ];



    return (

                    <div>
                        <Card>
                        <Table
                            dataSource={clientList.dataSource} columns={columns}
                        />


                        </Card>
                        <Card>
                            <pre>
                                {JSON.stringify(clientList.dataSource, undefined, 4)}
                            </pre>
                        </Card>
                    </div>
        );



}


export default  ClientList;