
import React, {Component, useContext, useEffect, useRef, useState} from 'react';

import {Button, Card, DatePicker, Input, Modal, Space, Table, version} from "antd";

import 'antd/dist/antd.dark.less';

import {SymbolModal, useSymbolModal} from "./SymbolModal";


export const useSplitAccountModal= ({closeCallback}) => {
    const [showModal, setShowModal] = useState(false);


    const accountsToAccountList = (accounts) => {
        var result = []
        var i = 1;
        accounts.forEach(acc=>{
            const accountValue = acc.account
            const accResult = acc.symbols.map((item, index)=>({key: i++,  account: accountValue, amount: item.amount, symbol: item.symbol}));
            console.log("accResult is ");
            console.log(accResult);
            accResult.forEach(item=>result.push(item))
        })
        console.log("accountsToAccountList is ");
        console.log(result);
        return result;
    }


    const [value, setValue] = useState();

    const accountListToAccounts = (value) => {
        if(!value) {
            return null;
        }
        var i = 1;
        const groupByAccount= value.reduce((group, item) => {
            const { account } = item;
            console.log(`reduce  ${account} `);
            if (! group.has(account)) {
                group.set(account, {key: i++, account: account, symbols: []});
            }
            group.get(account).symbols.push({key: item.key, symbol: item.symbol, amount: item.amount});

            return group;
        }, new Map());
        console.log("groupByAccount is ");
        console.log(groupByAccount);

        return Array.from(groupByAccount.values());
    }

    const closeModal = (value) => {
        setShowModal(false)
        closeCallback(accountListToAccounts(value))
    }

    const openModal = (accounts) => {
        console.log("openModal is")
        console.log(accounts)

        setShowModal(true)
        setValue(accountsToAccountList(accounts))

    }

    const createNewRow = (key) => {
        return { key:  key,
            account: 'account' + key,
            amount: null,
            symbol: 'A'
        };
    }


    const newRow = ()=> {
        const map = new Map(value.map(obj => [obj.key, obj]))

        map.set(value.length + 1, createNewRow(value.length + 1));
        setValue(Array.from(map.values()));
    }

    const updateRow = (row) => {

        const map = new Map(value.map(obj => [obj.key, obj]))

        map.set(row.key, row);

        setValue(Array.from(map.values()));

    }


    return {
        showModal,
        value,
        closeModal,
        openModal,
        newRow,
        updateRow
    }
}


const SplitAccountModal = ({splitAccountModal}) => {



    const RenderAccount = (_, row) => {

        const  changeHandler  = (e) => {
            const newRow = {...row, account: e.target.value};
            splitAccountModal.updateRow(newRow);
        }


        return (  <Input defaultValue={row.account}  value={row.account} onChange={changeHandler}/> );
    }


    const RenderAmount = (_, row) => {
        const  changeHandler  = (e) => {
            const newRow = {...row, amount: e.target.value};
            splitAccountModal.updateRow(newRow);
        }


        return (  <Input defaultValue={row.amount}  value={row.amount} onChange={changeHandler}/> );

    }



    const SymbolButton = ({row}) => {

        const symbolModal = useSymbolModal({ closeCallback: (newValue) => onCloseModal(newValue)})

        const  onClick  = () => {
            console.log("click")

            symbolModal.openModal(row.symbol);

        }

        const onCloseModal = (newValue) => {
            if(newValue==null) {
                return;
            }
            const newRow = {...row, symbol: newValue};
            splitAccountModal.updateRow(newRow);

        }

      return (
          <div>
            <Button onClick={onClick}>{row.symbol}</Button>
            <SymbolModal symbolModal={symbolModal}></SymbolModal>
          </div>
      );
    }

    const RenderButtonSymbol = (_, row) => {

        return (  <SymbolButton row={row}/>
            );
    }

    const columns = [
        {

            title: 'key',
            dataIndex: 'key',
            key: 'key',
        },
        {
            render: RenderAccount,
            title: 'account',
            dataIndex: 'account',
            key: 'account',
            sorter: true,
        },
        {
            render: RenderAmount,
            title: 'amount',
            dataIndex: 'amount',
            key: 'amount',
        },

        {
            render: RenderButtonSymbol,
            title: 'symbol',
            dataIndex: 'symbol',
            key: 'symbol',
        },
    ];



    const addHandler = () => {
        splitAccountModal.newRow();
        console.log(splitAccountModal.value);


    }

    const handleOk = () => {
        console.log("handleOk");
        splitAccountModal.closeModal(splitAccountModal.value)
    };

    const handleCancel = () => {
        console.log("handleCancel");
        splitAccountModal.closeModal(null)
    };


    return (
                <Modal  open={splitAccountModal.showModal} onOk={handleOk} onCancel={handleCancel}>
                    <div>
                        <Card>
                        <Table
                            dataSource={splitAccountModal.value} columns={columns}
                        />

                        <Button type="primary" onClick={addHandler}>Add</Button>
                        </Card>
                        <Card>
                            <pre>
                                {JSON.stringify(splitAccountModal.value, undefined, 4)}
                            </pre>
                        </Card>
                    </div>
                </Modal>

        );



}


export default  SplitAccountModal;