import {Modal, Table} from "antd";
import {useTableContext} from "./tableStore";
import {useEffect, useState} from "react";

const symbols = [
    {id: "A", name: "AAAA"},
    {id: "B", name: "VVV"},
    {id: "C", name: "VVV"},
]

const columns = [
    {

        title: 'id',
        dataIndex: 'id',
        key: 'id',
    },
    {
        title: 'Name',
        dataIndex: 'Name',
        key: 'Name',
    },

];

export const SymbolModal = ({row, show}) => {

    const state = useTableContext();

    const [isModalOpen, setIsModalOpen] = useState(show);

    const showModal = () => {
        setIsModalOpen(true);
    };


    const handleOk = () => {
        setIsModalOpen(false);
    };


    return (
      <Modal  open={show} onOk={handleOk} >
          <Table dataSource={symbols} columns={columns} ></Table>
      </Modal>
    );
}