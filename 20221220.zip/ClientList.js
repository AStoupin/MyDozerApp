
import React, {Component, useContext, useState} from 'react';

import {Button, Card, DatePicker, Input, Space, Table, version} from "antd";

import 'antd/dist/antd.dark.less';
import {useTableContext} from "./tableStore";
import {SymbolModal} from "./SymbolModal";

const ClientList = ()=>{

    const RenderInputAge = (_, row) => {

        const  changeHandler  = (e) => {
            const newRow = {...row, age: e.target.value};
            state.updateRow(newRow);
        }

        return (  <Input defaultValue={row.age}  onChange={changeHandler}/> );
    }

    const RenderInputName = (_, row) => {

        const  changeHandler  = (e) => {
            const newRow = {...row, name: e.target.value};
            state.updateRow(newRow);
        }

        return (  <Input defaultValue={row.name}  onChange={changeHandler}/> );
    }

    const RenderInputAddress = (_, row) => {

        const  changeHandler  = (e) => {
            const newRow = {...row, address: e.target.value};
            state.updateRow(newRow);
        }

        return (  <Input defaultValue={row.address}  onChange={changeHandler}/> );
    }

    const SymbolButton = ({row}) => {
        const [showModal, setShowModal] = useState(false);
        const  onClick  = () => {
            console.log("click")
             setShowModal(true)
        }
      return (  <div>
            <Button onClick={onClick}>{row.symbol}</Button>
            <SymbolModal row={row} show={showModal} ></SymbolModal>
        </div>
      );
    }

    const RenderButtonSymbol = (_, row) => {

        return (  <SymbolButton row={row}/>
            );
    }

    const columns = [
        {

            title: 'key',
            dataIndex: 'key',
            key: 'key',
        },
        {
            render: RenderInputName,
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
        },
        {
            render: RenderInputAge,
            title: 'Age',
            dataIndex: 'age',
            key: 'age',
        },
        {
            render: RenderInputAddress,
            title: 'Address',
            dataIndex: 'address',
            key: 'address',
        },

        {
            render: RenderButtonSymbol,
            title: 'symbol',
            dataIndex: 'symbol',
            key: 'symbol',
        },
    ];

    const state = useTableContext();
    const [resultDatasource, setResultDatasource] = useState(state.dataSource);
    const saveHandler = () => {
        console.log(state.dataSource);
        setResultDatasource(state.dataSource);

    }
    const addHandler = () => {
        state.newRow();
        console.log(state.dataSource);
        setResultDatasource(state.dataSource);

    }
    return (

                    <div>
                        <Card>
                        <Table dataSource={state.dataSource} columns={columns} />

                        <Button type="primary" onClick={saveHandler}>Save</Button>
                        <Button type="primary" onClick={addHandler}>Add</Button>
                        </Card>
                        <Card>
                            <pre>
                                {JSON.stringify(state.dataSource, undefined, 4)}
                            </pre>
                        </Card>
                    </div>
        );



}


export default  ClientList;