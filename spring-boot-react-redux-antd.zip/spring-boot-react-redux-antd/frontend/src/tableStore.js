
import React, {createContext, useContext, useState} from "react";


export const initialTableState =  [
        {
            key: 1,
            name: 'Mike',
            age: 32,
            address: '10 Downing Street',
        },
        {
            key: 2,
            name: 'John',
            age: 42,
            address: '10 Downing Street',
        },
    ];




const TableContext = createContext();

export const useTableContext = ()=> {

    return useContext(TableContext);
}


const TableProvider = ({children}) => {
    const [dataSource, setDataSource] = useState(initialTableState);
    const updateRow = (row) => {

        const map = new Map(dataSource.map(obj => [obj.key, obj]))

        map.set(row.key, row);
        setDataSource(Array.from(map.values()));

        //console.log(dataSource);
    }

    const getDataSource = () => {
        return dataSource;
    }

    const newRow = ()=> {
        const map = new Map(dataSource.map(obj => [obj.key, obj]))

        map.set(dataSource.length + 1, { key:  dataSource.length + 1,
            name: 'Noname' + (dataSource.length + 1),
            age: 0,
            address: null
        });
        setDataSource(Array.from(map.values()));
    }

    return (

        <TableContext.Provider value={{
            dataSource,
            newRow,
            updateRow,
            getDataSource
        }}>
            {children}
        </TableContext.Provider>
    );
}

export default  TableProvider;