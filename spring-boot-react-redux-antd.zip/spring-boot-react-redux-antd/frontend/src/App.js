import React, {Component, useContext} from 'react';
import {HashRouter,  BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import {ConfigProvider, Button} from 'antd';


import './App.css';
import 'antd/dist/antd.dark.css';



import ClientList from "./ClientList";
import TableProvider from "./tableStore";


class App extends Component {

    render() {
        return (
            <TableProvider>
                <ClientList/>
            </TableProvider>
        )

    }
}



export default App;
